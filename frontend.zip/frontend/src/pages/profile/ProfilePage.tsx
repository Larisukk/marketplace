import React from "react";
import MainHeader from "../../components/MainHeader";
import { useAuth } from "../../context/AuthContext";
import "./Profile.css";

export default function ProfilePage() {
    const { user } = useAuth();

    return (
        <div className="profile-page-wrapper">
            <MainHeader />

            <div className="profile-card-split">

                {/* STÂNGA: BOX cu datele utilizatorului */}
                <div className="profile-left-box">
                    <h2>Datele contului</h2>

                    <div className="profile-field">
                        <label>Nume:</label>
                        <p>{user?.displayName || "—"}</p>
                    </div>

                    <div className="profile-field">
                        <label>Email:</label>
                        <p>{user?.email || "—"}</p>
                    </div>

                    <div className="profile-field">
                        <label>ID:</label>
                        <p>{user?.id || "—"}</p>
                    </div>

                    <div className="profile-field">
                        <label>Rol:</label>
                        <p>{user?.role || "—"}</p>
                    </div>
                </div>

                {/* DREAPTA: IMAGINEA */}
                <div className="profile-right-image"></div>

            </div>
        </div>
    );
}
