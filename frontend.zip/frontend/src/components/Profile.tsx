import React from "react";
import "./Profile.css";

export default function Profile() {
    return (
        <div className="profile-card-empty">

        </div>
    );
}
