import "./App.css";
import { Routes, Route, Navigate } from "react-router-dom";

import MapPage from "./pages/mappage/MapPage";
import Home from "./pages/homePage/Home";
import UploadProductPage from "./pages/uploadProductPage/UploadProductPage";
import AuthPage from "./pages/AuthPage";
import ProfilePage from "./pages/profile/ProfilePage";

import { useAuth } from "./context/AuthContext";

export default function App() {
    const { user } = useAuth();

    return (
        <Routes>
            {/* Redirect de la root */}
            <Route path="/" element={<Navigate to="/home" replace />} />

            {/* Oricine poate vedea HOME */}
            <Route path="/home" element={<Home />} />

            {/* LOGIN / REGISTER */}
            {/* Dacă e logat → merge direct la profil */}
            <Route
                path="/auth"
                element={!user ? <AuthPage /> : <Navigate to="/profile" replace />}
            />

            {/* PROFILE – protejat */}
            <Route
                path="/profile"
                element={user ? <ProfilePage /> : <Navigate to="/auth" replace />}
            />

            {/* UPLOAD – protejat */}
            <Route
                path="/upload"
                element={user ? <UploadProductPage /> : <Navigate to="/auth" replace />}
            />

            {/* MAP – protejat */}
            <Route
                path="/map"
                element={user ? <MapPage /> : <Navigate to="/auth" replace />}
            />
        </Routes>
    );
}
