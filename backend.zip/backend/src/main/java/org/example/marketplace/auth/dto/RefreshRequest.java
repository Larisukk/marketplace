package org.example.marketplace.auth.dto;
public record RefreshRequest(String refreshToken) {}