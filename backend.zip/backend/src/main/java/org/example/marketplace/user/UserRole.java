package org.example.marketplace.user;

public enum UserRole { USER, FARMER, ADMIN }
